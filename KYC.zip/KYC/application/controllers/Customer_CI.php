<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_CI extends CI_Controller {

	 function __construct()
	 {
		parent::__construct();
		 
		$this->load->model('Customer_Model');
		 
	}
	public function index()
	{
		$this->load->view('customer_view');
			
	}
	function viewall()
	{
		 $data['res'] = $this->Customer_Model->getall();
        $this->load->view('customer_details',$data);
		 
	}
	function save()
	{
		 $error = 0 ; 
		$this->form_validation->set_rules('fname' , 'FirstName', 'required');
		$this->form_validation->set_rules('lname' , 'LastName', 'required');
		$this->form_validation->set_rules('dob' , 'Date Of Birth', 'required|callback_date_valid');
		$this->form_validation->set_rules('phone' , 'Phone', 'required|numeric|max_length[10]');

		if ($this->form_validation->run() == true) 

		{
			$data = array();
			$error = array();
			$new_name =  $this->input->post('fname').'_'.$this->input->post('lname').'_Aadhar_'.$_FILES["aadharcard"]['name'];
			$config1['file_name'] = $new_name;
			$config1['upload_path'] = './uploads/doc/';
			$config1['allowed_types'] = 'gif|jpeg|png|jpg';
			$config1['max_size'] = '2000';
			$config1['max_width'] = '0';
			$config1['max_height'] = '0';
			$this->load->library('upload', $config1);
			if (!$this->upload->do_upload('aadharcard')   )
			{
			 
			      $error['err'] = 1 ; 
			}
			else 
			{
    			$adata = $this->upload->data();
      			$data['aadharcard'] =    $adata['file_name'];
    		}

			$new_name1 =  $this->input->post('fname').'_'.$this->input->post('lname').'_PAN_'.$_FILES["pancard"]['name'];
			$config2['file_name'] = $new_name1;
			$config2['upload_path'] = './uploads/doc';
			$config2['allowed_types'] = 'gif|jpeg|png|jpg';
			$config2['max_size'] = '2000';
			$config2['max_width'] = '0';
			$config2['max_height'] = '0';
			$this->upload->initialize($config2);

			if (!$this->upload->do_upload('pancard'))
			{
			   $error['err'] = 1 ; 
			}
			else 
			{
			    $fdata = $this->upload->data();
			    $data['pancard'] =  $fdata['file_name'];
			}
 
				if( $error['err'] == 1 )
				{
					   	$error['aadharerr'] =  $this->upload->display_errors();
     
      					$error['panerr'] =  $this->upload->display_errors();
	   
						$this->load->view('customer_view' , $error);
				}
				else
				{
					$data['FirstName'] = $this->input->post('fname', TRUE);
				    $data['LastName'] = $this->input->post('lname', TRUE);
				    $data['dob'] = $this->input->post('dob', TRUE);
				    $data['phone'] = $this->input->post('phone', TRUE);

				    $result = $this->db->insert('customer' , $data);
				///  $result = $this->db->insert('customer' , $data);
					if($result)
					 {
					 			$this->session->set_flashdata('msg', 'Customer information saved');
								redirect('index.php/customer_CI');
					 }
				}
 	
	 		}

			else
			{
				$this->load->view('customer_view');
			}
	}
	public function date_valid($date)
	  {
	    $parts = explode("/", $date);
	    if (count($parts) == 3) {      
	      if (checkdate($parts[1], $parts[0], $parts[2]))
	      {
	        return TRUE;
	      }
	    }
	    $this->form_validation->set_message('date_valid', 'The Date field must be mm/dd/yyyy');
	    return false;
	  }

	  public function delete($id)
   {
       $this->db->delete('customer', array('id' => $id));
       echo 'Deleted successfully.';
   }
}
