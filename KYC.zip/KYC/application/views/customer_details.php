<!DOCTYPE html>
<html>
<head>
<title>User profile Details</title>
 
<link href="<?php echo base_url()?>assests/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
 

<!------ Include the above in your HEAD tag ---------->
<style type="text/css">
	 body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    .ht30{height: 30px;}
</style>
</head>
<body>
<div class="container">
<div class="row">
		
		<?php if($this->session->flashdata('msg')): ?>
			<div class="alert alert-info alert-dismissable">
    		<p><?php echo $this->session->flashdata('msg'); ?></p>
			
          <a class="panel-close close" data-dismiss="alert">×</a> 
           
        </div>
        <?php endif; ?>
        <div class="col-md-10 ">
        		<button type="button" class="btn btn-primary"  onclick="location.href='<?php echo base_url();?>index.php/customer_CI/viewall'">View</button>
        		<button type="button" class="btn btn-warning"  onclick="location.href='<?php echo base_url();?>index.php/customer_CI'">Add Details</button>
        		 
				 
        </div>
      <div class="ht30"></div>  
 <br>	
<div class="col-md-10 ">
	<table id="example" class="table table-striped table-bordered" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>FirstName</th>
                <th>LastName</th>
                <th>Mobile</th>
                <th>Date Of Birth(mm/dd/yyyy)</th>
                <th>AadharCard</th>
                <th>PanCard</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
        	<?php 
$i=1;
foreach ($res as $key => $value)  { ?>


            <tr id="<?php echo $value->id; ?>">
                <td><?php echo $i;?></td>
                <td><?php echo ucwords($value->FirstName);?></td>
                <td><?php echo ucwords($value->LastName);?></td>
                 <td><?php echo $value->phone;?></td>
                <td><?php echo $value->dob;?></td>
               
                 
                <td><img src="<?php echo base_url().'uploads/doc/'.$value->aadharcard ?>" class="img-responsive"  width='50' height='50'></td>
                <td><img src="<?php echo base_url().'uploads/doc/'.$value->pancard ?>" class="img-responsive" width='50' height='50'></td>
                <td><button type="submit" class="btn btn-danger remove"> Delete</button></td>
                
                 
            </tr>
 

            <?php $i++ ; } ?>
           
             
        </tbody>
    </table>
</div>

</div>
</div>
<script src="<?php echo base_url()?>assests/bootstrap/js/jquery-1.11.1.min.js"></script>
<script src="<?php echo base_url()?>assests/bootstrap/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url()?>assests/bootstrap/js/dataTables.bootstrap.min.js"></script>

 
<script type="text/javascript">
    $(".remove").click(function(){
        var id = $(this).parents("tr").attr("id");
 
 
        if(confirm('Are you sure to remove this record ?'))
        {
            $.ajax({
               url: '<?php echo base_url()?>index.php/customer_CI/delete/'+id,
               type: 'DELETE',
               error: function() {
                  alert('Something is wrong');
               },
               success: function(data) {
                    $("#"+id).remove();
                    alert("Record removed successfully");  
               }
            });
        }
    });
</script>
 <script type="text/javascript">
 	   $(document).ready(function() {
    $('#example').DataTable();
} );

 </script>

</body>
</html>