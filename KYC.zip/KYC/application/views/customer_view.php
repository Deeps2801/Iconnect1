<!DOCTYPE html>
<html>
<head>
<title>User profile form requirement</title>
 
<link href="<?php echo base_url()?>assests/bootstrap/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
 
<link rel="stylesheet" href="<?php echo base_url()?>assests/css/font-awesome.css">
<!------ Include the above in your HEAD tag ---------->
<style type="text/css">
	 body {
        padding-top: 70px;
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    .ht30{height: 30px;}
</style>
</head>
<body>
	<div class="panel panel-default">
    <div class="panel-heading col-md-12">
    	
<div class="col-md-10">
    	<h4 style="margin: 0px;">KYC Form</h4>
    </div>
    <div class="col-md-2">
    	<button type="button" class="btn btn-primary"  onclick="location.href='<?php echo base_url();?>index.php/customer_CI/viewall'">View</button>
    </div>
    </div>

    
  </div>
<div class="container">
<div class="row">
		
		<?php if($this->session->flashdata('msg')): ?>
			<div class="alert alert-info alert-dismissable">
    		<p><?php echo $this->session->flashdata('msg'); ?></p>
			
          <a class="panel-close close" data-dismiss="alert">×</a> 
           
        </div>
        <?php endif; ?>
        <div class="col-md-10 ">
        		
				 
        </div>
      <div class="ht30"></div>  
 <br>	
<div class="col-md-10 ">
	<form class="form-horizontal"  action = "<?php echo base_url();?>index.php/customer_CI/save" method='post' enctype="multipart/form-data" id="form" role="form" name='form' >
		<div class="form-group">
  		<label class="col-md-4 control-label" for="Name (Full name)">First Name  </label>  
  			<div class="col-md-4">
 				<div class="input-group">
       				<div class="input-group-addon">
        				<i class="fa fa-user"> </i>
       				</div>
       				<input id="fname" name="fname" type="text" placeholder="FirstName" class="form-control input-md"value="<?php echo   set_value('fname'); ?>"><br>
       				
      			</div>
      			<?php echo form_error('fname'); ?>
 			</div>
 		</div>
 		<div class="form-group">
  		<label class="col-md-4 control-label" for="LastName">Last Name  </label>  
  			<div class="col-md-4">
 				<div class="input-group">
       				<div class="input-group-addon">
        				<i class="fa fa-user"> </i>
       				</div>
       				<input id="lname" name="lname" type="text" placeholder="LastName" class="form-control input-md" value="<?php echo set_value('lname'); ?>"><br>
       				
      			</div>
      			<?php echo form_error('lname'); ?>
 			</div>
 		</div>
 		<!-- Text input-->
		<div class="form-group">
		  	<label class="col-md-4 control-label" for="Date Of Birth">Date Of Birth</label>  
		  		<div class="col-md-4">
 					<div class="input-group">
		       			<div class="input-group-addon">
		     				<i class="fa fa-calendar" aria-hidden="true"></i>
		         		</div>
		       			<input id="dob"  name="dob" type="text" placeholder="Date Of Birth"  value="<?php echo set_value('dob'); ?>" class="form-control input-md">
		       			
		      		</div>
		      		<?php echo form_error('dob'); ?>
		  		</div>
		</div>
		<div class="form-group">
		  	<label class="col-md-4 control-label" for="Phone number ">Phone number </label>  
		  		<div class="col-md-4">
		  			<div class="input-group">
		       			<div class="input-group-addon">
		     				<i class="fa fa-phone"></i>
		         		</div>
		    			<input id="phone" name="phone" type="text" placeholder="Phone number " value="<?php echo set_value('phone'); ?>" class="form-control input-md">
		    			<br>
		    			
		     		</div>
		     		<?php echo form_error('phone'); ?>
		       </div>
		</div>
 		<!-- File Button --> 
		<div class="form-group">
		  	<label class="col-md-4 control-label" for="Upload photo">Upload Aadhar Card</label>
		  		<div class="col-md-4">
		    		<input id="aadharcard" name="aadharcard" class="input-file" type="file">
		  		</div>
		  		 
		  		<?php if(isset($aadharerr))  {echo $aadharerr ;  } ?>
		</div>
		<!-- File Button --> 
		<div class="form-group">
		  	<label class="col-md-4 control-label" for="Upload photo">Upload Pan Card</label>
		  		<div class="col-md-4">
		    		<input id="pancard" name="pancard" class="input-file" type="file">
		  		</div>
		  		<?php if(isset($panerr))  {echo $panerr ;  } ?>
		</div>
		<div class="form-group">
		  	<label class="col-md-4 control-label" for=""><button class="btn btn-info" type="submit" name="showpassword" id="showpassword" value="Show Password">Submit</button> </label>
        </div>
	</form>
</div>
</div>
</div>
<script src="<?php echo base_url()?>assests/bootstrap/js/jquery-1.11.1.min.js"></script>
<!-- jQuery Version 1.11.1 -->
<script src="<?php echo base_url()?>assests/bootstrap/js/bootstrap.min.js"></script>
 <!-- Bootstrap Core JavaScript -->
 <script type="text/javascript">
 	   setTimeout(function() {
    $('.alert').fadeOut('fast');
}, 3000); // <-- time in milliseconds

 	$(function() {
        $( "#datepicker" ).datepicker({
            dateFormat : 'mm/dd/yy',
            changeMonth : true,
            changeYear : true,
            yearRange: '-100y:c+nn',
            maxDate: '-1d'
        });
    });

 </script>

</body>
</html>