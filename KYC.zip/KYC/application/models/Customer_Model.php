 
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customer_Model extends CI_Model 
{ 
		function getall()
		{
			 $this->db->select("*"); 
			 $this->db->from('customer');
			 $query = $this->db->get();
			 return $query->result();
		}
}

?>
